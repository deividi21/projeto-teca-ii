extern void parseBytes(const char* str, char sep, byte* bytes, int maxBytes, int base);
