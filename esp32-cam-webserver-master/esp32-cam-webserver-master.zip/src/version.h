/* Version of upstream code */

char baseVersion[] = "3.0-RC2";
